package com.example.registronotas;



public class Alumno {
    private String ID, IDEN;
    private String Nombre;
    private String Apellido;
    private float Nota1, Nota2, Nota3, NotaFinal;

    public Alumno(String ID, String iden, String nombre, String apellido, float nota1, float nota2, float nota3) {
        this.ID = ID;
        IDEN = iden;
        Nombre = nombre;
        Apellido = apellido;
        Nota1 = nota1;
        Nota2 = nota2;
        Nota3 = nota3;
    }

    public float getNota1() {
        return Nota1;
    }

    public void setNota1(float nota1) {
        Nota1 = nota1;
    }

    public float getNota2() {
        return Nota2;
    }

    public void setNota2(float nota2) {
        Nota2 = nota2;
    }

    public float getNota3() {
        return Nota3;
    }

    public void setNota3(float nota3) {
        Nota3 = nota3;
    }

    public float getNotaFinal() {
        return NotaFinal;
    }

    public void setNotaFinal(float notaFinal) {
        NotaFinal = notaFinal;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public String getIDEN() {
        return IDEN;
    }

    public void setIDEN(String IDEN) {
        this.IDEN = IDEN;
    }

    public void SaveAlumno(){ Data.Save(this);}
}
