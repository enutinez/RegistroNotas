package com.example.registronotas;

import java.util.ArrayList;

public class Data {

    private static ArrayList<Alumno> alumnos = new ArrayList<>();
    public static void Save (Alumno a){ alumnos.add(a);}
    public static ArrayList<Alumno> Get(){return alumnos;}

}
