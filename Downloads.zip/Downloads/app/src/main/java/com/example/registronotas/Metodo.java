package com.example.registronotas;

public class Metodo {

    public static float Calcular (float nota1, float nota2, float nota3){
        float notaFinal = 0;
            notaFinal = (nota1 + nota2 + nota3)/3;
        return notaFinal;
    }
}
