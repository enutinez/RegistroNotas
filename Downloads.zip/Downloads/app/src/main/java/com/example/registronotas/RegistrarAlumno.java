package com.example.registronotas;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RegistrarAlumno extends AppCompatActivity {

    private TextView ID, Nombre, Apellido, Nota1, Nota2, Nota3;
    private ArrayList<Alumno> Alumnos;
    private Resources Resources;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar_alumno);

    ID = (TextView)findViewById(R.id.TxtID);
    Nombre = (TextView)findViewById(R.id.TxtNombre);
    Apellido = (TextView)findViewById(R.id.TxtApellido);
    Nota1 = (TextView)findViewById(R.id.TxtNota1);
    Nota2 = (TextView)findViewById(R.id.TxtNota2);
    Nota3 = (TextView)findViewById(R.id.TxtNota3);
    Resources = this.getResources();
    Alumnos = Data.Get();


    }

public void Save(View view){
    String IDV, IDEN, NombreV, ApellidoV;
    float Nota1V, Nota2V, Nota3V;
    IDV = (Alumnos.size() + 1) + "";
    IDEN = ID.getText().toString();
    NombreV = Nombre.getText().toString();
    ApellidoV = Apellido.getText().toString();
    Nota1V = Float.parseFloat(Nota1.getText().toString());
    Nota2V = Float.parseFloat(Nota2.getText().toString());
    Nota3V = Float.parseFloat(Nota3.getText().toString());
    Alumno A = new Alumno(IDV, IDEN, NombreV, ApellidoV, Nota1V, Nota2V, Nota3V);
    A.SaveAlumno();
    Toast.makeText(this, R.string.registrado, Toast.LENGTH_LONG).show();

    }
}
