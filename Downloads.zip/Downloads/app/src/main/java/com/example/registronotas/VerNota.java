package com.example.registronotas;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class VerNota extends AppCompatActivity {
    private Intent In;
    private ListView LV;
    private Resources Resources;
    private ArrayList<String> listaA;
    private ArrayList<Alumno> Alumnos;
    private TextView NoResultado;
    private Metodo M;
    private float NotaFinal;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ver_nota);

        LV = (ListView)findViewById(R.id.ListaNotas);
        Alumnos = Data.Get();
        listaA = new ArrayList<String>();
        NoResultado = (TextView)findViewById(R.id.TxtNoResultado);

        NoResultado.setVisibility(View.VISIBLE);

        if (Alumnos.size() > 0){
            LV.setVisibility(View.VISIBLE);
            NoResultado.setVisibility(View.INVISIBLE);

            for (int i = 0; i< Alumnos.size(); i++){

                NotaFinal = M.Calcular(Alumnos.get(i).getNota1(),Alumnos.get(i).getNota2(),Alumnos.get(i).getNota3());
                Alumnos.get(i).setNotaFinal(NotaFinal);

            listaA.add(Alumnos.get(i).getNombre()+ " " + Alumnos.get(i).getApellido()+ "\n Nota final: "+ Alumnos.get(i).getNotaFinal());
            }

        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,listaA);
        LV.setAdapter(adapter);



    }
}
